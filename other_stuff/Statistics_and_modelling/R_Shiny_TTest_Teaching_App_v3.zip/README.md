# Understanding statistical tests — Shiny teaching app (version 3)

An interactive, single-file **R Shiny** teaching app comparing statistical significance and statistical power for a two-sample Student t-test, the Wilcoxon rank-sum (Mann–Whitney) test, and the two-sample Kolmogorov–Smirnov (KS) test. It also demonstrates **sampling variability and repeated-sampling coverage of confidence intervals**.

All teaching interface text and comments in the R code are in English. The app needs only **`shiny`**; all statistical calculations use base R.

## Launch

1. Extract the ZIP (or download `app.R`) to a folder.
2. In R/RStudio, install Shiny once:
   ```r
   install.packages("shiny")
   ```
3. Open `app.R` in RStudio and click **Run App**, or execute this command from its folder:
   ```r
   shiny::runApp("app.R")
   ```

After installation of `shiny`, the app can run without internet access.

## Statistical model

The underlying populations are deliberately simple to make statistical power interpretable:

- Group A: Normal distribution with mean **0** and standard deviation **sigma**.
- Group B: Normal distribution with mean **delta** and **the same** standard deviation **sigma**.
- Two independent groups, each with **n** observations. Sample sizes are equal.
- All tests are **two-sided** at user-selected significance level **alpha**.
- `n`, `delta`, `sigma`, and `alpha` can be adjusted using sliders.

**Important:** Under these model assumptions, the t-test is typically the most efficient test for detecting a difference in the means. However, **non-parametric tests are not universally less powerful**. In particular, the Wilcoxon test can outperform the t-test under some heavy-tailed distributions; that situation cannot be demonstrated using the app's current *normal-only* population model.

## New in version 3: choose one or both non-parametric tests

In the sidebar, use the checkboxes under **Compare statistical tests**:

- **Wilcoxon rank-sum (Mann–Whitney)**: A test based on the relative ranks of observations. Under equal-shape, equal-scale continuous distributions it can be interpreted as a comparison of locations. Under more general alternatives, it is not simply a test of mean equality.
- **Kolmogorov–Smirnov (KS)**: An omnibus test of whether the two population distribution functions are equal. It can detect changes in location, spread, or shape. Although it is a useful contrast, it targets a *broader class of differences* than a t-test.

The **Student t-test remains visible** regardless of the selected checkboxes. Changing the selection does not generate another observed sample: all p-values in the comparison table are based on **exactly the same data**. Clicking **Draw a new random sample** changes all observed results together.

### New power curves in panel 4

- **Blue Student t-test:** exact theoretical power under the stated assumptions, using the noncentral t distribution.
- **Teal dashed Wilcoxon:** approximate power using a normal approximation to the rank-sum statistic, with its mean and variance calculated for the specified normal-shift alternative. It is **not an exact finite-sample power calculation**, particularly for `n = 5` or similarly small sample sizes. The observed Wilcoxon p-value uses R's asymptotic normal approximation with no continuity correction (`exact = FALSE, correct = FALSE`).
- **Purple KS:** simulated power at 18 values of `n` between 5 and 300. Each point is estimated from **400 repeated pairs of independent samples** using the asymptotic two-sample KS test (`exact = FALSE`). Intermediate n values in the results table are linearly interpolated. **Monte Carlo error** causes some visible jaggedness; at 400 simulations, a power estimate near 50% has a Monte Carlo standard error of about 2.5 percentage points. The results are reproduced with a fixed random seed for stable slider comparisons. KS power is computed only when the KS checkbox is selected.

The **dots** identify the selected n, and the **80%** power reference line remains.

### New interpretation table

Below the plots, the app presents a side-by-side table containing, for each displayed test:

- The null hypothesis being tested
- The observed test statistic
- The observed two-sided p-value
- Reject / do not reject H0 at the chosen alpha
- Power at the selected sample size (with clear labels for exact, approximate and Monte Carlo quantities)
- Confidence interval: shown **only for the Student t-test**

The t-test confidence interval estimates the **difference in population means**. A Wilcoxon or KS test does **not** automatically supply the same confidence interval. Showing that t-based interval in the other test columns would be misleading.

## Existing tab 1: Single study & power

1. Population distributions and their overlap: changing n does not alter them.
2. Sampling distributions of the mean difference: theoretical SE = `sigma * sqrt(2 / n)`.
3. Two-sided Student t-test p-value as the tail area under the null distribution.
4. Statistical power as a function of n: exact t, optionally approximate Wilcoxon and simulated KS.

## Existing tab 2: Repeated samples & CI coverage

The second tab is intentionally **specific to the t-test's confidence interval for the difference in means**, not to the Wilcoxon or KS test. It simulates 10–1000 independent experiments (each with n observations in both groups):

- A **blue confidence interval** contains the true difference `delta`.
- An **orange confidence interval** misses the true difference.
- A **filled rose dot** denotes a statistically significant **t-test** (interval excludes 0).
- A **violet dashed line** marks the true difference; a **gray dotted line** marks 0.

Empirical coverage and the share of statistically significant t-tests are reported alongside theoretical coverage `1 - alpha` and exact t-test power, with a running-rate graph.

Unlike approximating a 95% confidence interval as the estimate ± 1.96 SE, this app uses the pooled Student t-based interval with `2*n - 2` degrees of freedom, matching the t-test even for small n.

## Suggested classroom experiments

**Exercise 1 — Compare tests in a normal model.** Set `delta = 1`, `sigma = 1.5`, `alpha = .05`, and `n = 30`. Check Wilcoxon and KS. Observe the close t–Wilcoxon power curves versus the usually less powerful omnibus KS curve for this **specific normal location-shift setting**.

**Exercise 2 — More data.** Increase n from 30 to 200. The population overlap stays the same, SE decreases, and the power of each test increases. Observed p-values need not decrease monotonically for every possible sample.

**Exercise 3 — Null hypothesis true.** Set `delta = 0`. No test should systematically yield high power. Its rejection rate is a type I error probability near `alpha` (the KS and Wilcoxon tests use approximate finite-sample p-values, so their realized null rejection rates can differ at small n).

**Exercise 4 — Effect size and variability.** Hold n fixed, increase `delta`, and then increase `sigma`. Watch how effect size, overlap, p-values, and rejection probabilities change.

**Exercise 5 — Same samples, different p-values.** Compare p-values and decisions for the three methods using the same sample. Click **Draw a new random sample** several times. A disagreement between tests is possible, particularly when power is moderate.

**Exercise 6 — CI coverage vs. significance.** In the repeated-samples tab, set `delta = 0`, `alpha = .05`, and simulate 1000 samples. Observe ~95% CI coverage and ~5% significant t-test results. Then set `delta = 1`: coverage stays ~95%, but significant-result rate rises.

## Limitations and appropriate interpretation

1. The displayed population model is normal with equal variance, equal sample size, and independent observations. It does **not** model outliers, skewness, heavy tails, unequal sample sizes, non-independence, censoring, or multiple testing.
2. The Student t-test is the **pooled-variance** form, not Welch's t-test. Its exact t power and confidence interval rely on the model assumptions.
3. Wilcoxon and KS do not test precisely the same general alternative as the t-test. Their null hypotheses coincide for the chosen **normal shift model**, but they have different interpretations in other settings.
4. The Wilcoxon power curve is approximate; the KS power curve is a simulation estimate, not an exact analytic power curve. They should not be interpreted as precise enough to establish tiny performance differences.
5. With `n=5`, asymptotic methods for rank and KS tests can be noticeably less accurate. Their simulated rejection rates at delta = 0 need not exactly equal alpha. If exact small-sample inference is the teaching objective, use an appropriately configured exact test instead.
6. A non-significant result is not evidence of equivalence or equality, and a p-value is **not** the probability that the null hypothesis is true.

## Source relationship

The **repeated sampling & CI coverage** tab builds on the supplied `sampling_variability.r` teaching example, extending its single-mean confidence intervals to **two-sample mean differences**. Version 3 does not change that tab's statistical target; it adds optional comparisons of other hypothesis tests to the first tab.
