# Interactive teaching app: parametric and non-parametric two-sample tests
# =======================================================================
# Dependencies: shiny only (all statistics and plots use base R).
# Run with: shiny::runApp("app.R")
#
# Teaching assumptions:
#   * Two independent samples of equal size n.
#   * Normal populations with means mu_A = 0 and mu_B = delta.
#   * Both populations have the same standard deviation sigma.
#   * The reference analysis is a two-sided equal-variance Student t-test.
#   * Optional comparisons: Wilcoxon rank-sum and Kolmogorov-Smirnov tests.
#   * Exact t power, approximate Wilcoxon power, simulated KS power.
#   * Under normality the t-test is highly efficient; non-parametric tests
#     are NOT universally less powerful under other distributions.
#
# The sampled standard-normal observations stay fixed when sliders move.
# The second tab repeats this experiment to demonstrate CI coverage and power.
# This makes comparisons easier. The 'Draw a new sample' button produces
# another independent pair of samples and another observed p-value.

if (!requireNamespace("shiny", quietly = TRUE)) {
  stop("Install the package first: install.packages('shiny')")
}
library(shiny)

# Colors are chosen for legibility and to avoid red-green comparisons.
col_A <- "#2563EB"      # blue
col_B <- "#D97706"      # amber
col_null <- "#475569"   # slate
col_p <- "#BE123C"      # rose: statistically significant
col_true <- "#7C3AED"   # violet: true parameter
col_wilcox <- "#087F8C" # teal: Wilcoxon rank-sum
col_ks <- "#9333EA"     # purple: Kolmogorov-Smirnov

# Exact power for the two-sided, pooled-variance two-sample t-test.
# Here n is the number of participants in EACH group.
power_two_sample <- function(n, delta, sigma, alpha) {
  df <- 2 * n - 2
  critical <- qt(1 - alpha / 2, df = df)
  ncp <- delta / (sigma * sqrt(2 / n))

  # Both tails must be counted, including when delta = 0.
  pt(-critical, df = df, ncp = ncp) +
    pt(critical, df = df, ncp = ncp, lower.tail = FALSE)
}

# Normal approximation to power for the two-sided Mann-Whitney/Wilcoxon
# rank-sum test under TWO NORMAL POPULATIONS with equal SD and group size.
# This is a power approximation, not an exact small-sample calculation.
# U counts the n^2 ordered (B > A) pairs (continuous data, no ties).
# theta = P(B > A), q = E[P(A < B | B)^2]. The variance under the
# alternative includes covariance from pairs sharing an observation.
# When delta = 0, the formula reduces to the null rank-sum variance.
# See the README for limitations at small n.
wilcoxon_power_normal <- function(n, delta, sigma, alpha) {
  d <- delta / sigma
  theta <- pnorm(d / sqrt(2))
  q <- integrate(function(z) pnorm(d + z)^2 * dnorm(z),
                 lower = -9, upper = 9,
                 rel.tol = 1e-8)$value
  n <- as.numeric(n)
  mean0 <- n^2 / 2
  mean1 <- n^2 * theta
  sd0 <- n * sqrt((2 * n + 1) / 12)
  var1 <- n^2 * (theta * (1 - theta) +
                 2 * (n - 1) * pmax(0, q - theta^2))
  sd1 <- sqrt(pmax(var1, 1e-12))
  z <- qnorm(1 - alpha / 2)
  low <- mean0 - z * sd0
  high <- mean0 + z * sd0
  power <- pnorm(low, mean = mean1, sd = sd1) +
    pnorm(high, mean = mean1, sd = sd1, lower.tail = FALSE)
  pmin(1, pmax(0, power))
}

# Empirical power of the two-sided, asymptotic two-sample KS test.
# KS tests equality of FULL distributions, not specifically means.
# We use a fixed random seed so moving a slider does not introduce a new
# random Monte Carlo run; a coarse grid limits waiting time.
ks_sample_sizes <- c(5L, 10L, 15L, 20L, 25L, 30L, 40L, 50L, 60L,
                     75L, 90L, 110L, 135L, 160L, 190L, 225L,
                     260L, 300L)
ks_repetitions <- 400L

format_p <- function(p) {
  format.pval(p, digits = 3, eps = 0.0001)
}

plot_setup <- function() {
  par(
    mar = c(4.1, 4.2, 2.8, 0.9),
    mgp = c(2.4, 0.65, 0),
    cex.axis = 0.90,
    cex.lab = 0.95,
    bg = "white",
    las = 1
  )
}

metric_card <- function(title, value, subtext = NULL, accent = NULL) {
  tags$div(
    class = "metric-card",
    tags$div(class = "metric-label", title),
    tags$div(class = "metric-number", style = if (!is.null(accent))
      paste0("color:", accent, ";") else NULL, value),
    if (!is.null(subtext)) tags$div(class = "metric-sub", subtext)
  )
}

ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body { background: #F8FAFC; color: #1E293B; }
      .page-heading { padding: 13px 0 9px; }
      .page-heading h2 { font-weight: 700; margin-bottom: 6px; }
      .page-heading p { color: #64748B; max-width: 1050px; }
      .well { background: #FFFFFF; border: 1px solid #E2E8F0;
              box-shadow: none; border-radius: 10px; }
      .chart-panel { background: #FFFFFF; border: 1px solid #E2E8F0;
                     border-radius: 10px; padding: 9px 11px 1px;
                     margin-bottom: 15px; }
      .chart-caption { font-size: 12px; line-height: 1.45;
                       color: #475569; min-height: 42px; margin-bottom: 11px; }
      .metric-grid { display: grid;
                     grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));
                     gap: 9px; margin: 0 0 14px; }
      .metric-card { background: #FFFFFF; border: 1px solid #E2E8F0;
                     border-radius: 10px; padding: 11px 12px; }
      .metric-label { font-size: 12px; font-weight: 600; color: #64748B; }
      .metric-number { font-size: 24px; line-height: 1.3;
                       font-weight: 700; margin: 5px 0; }
      .metric-sub { font-size: 11px; line-height: 1.3; color: #64748B; }
      .explain-panel { background: #FFFFFF; border: 1px solid #E2E8F0;
                       border-radius: 10px; padding: 14px 17px;
                       line-height: 1.55; margin-bottom: 18px; }
      .explain-panel p { margin: 0 0 7px; }
      .explain-panel p:last-child { margin-bottom: 0; }
      .sidebar-title { font-weight: 700; margin-top: 0; }
      .controls-note { font-size: 12px; line-height: 1.5; color: #64748B; }
      .btn-default { border-radius: 7px; }
      .shiny-input-container { width: 100%; }
      .tab-content { padding-top: 15px; }
      .simulation-note { font-size: 12px; color: #475569; line-height: 1.55; }
      .legend-line { font-weight: bold; }
      .test-table { width: 100%; table-layout: fixed; border-collapse: collapse;
                    font-size: 13px; margin: 10px 0; }
      .test-table th, .test-table td { padding: 10px 9px;
                                      border: 1px solid #E2E8F0;
                                      vertical-align: top; overflow-wrap: break-word; }
      .test-table thead th { background: #F1F5F9; }
      .test-table tbody th { width: 20%; background: #F8FAFC; }
      .test-table .test-col { min-width: 130px; }
      .test-table-wrap { width: 100%; overflow-x: auto; }
      .test-note { font-size: 12px; line-height: 1.5; color: #475569; }
      @media (max-width: 767px) {
        .chart-caption { min-height: 0; }
      }
    "))
  ),
  div(
    class = "page-heading",
    h2("Understanding statistical significance"),
    p("Interactive comparison of a parametric t-test and optional rank-based or distributional tests: sample size, variability, p-values, confidence intervals, and power")
  ),
  sidebarLayout(
    sidebarPanel(
      width = 3,
      h4(class = "sidebar-title", "Change the population"),
      sliderInput("n", "Sample size per group (n)",
                  min = 5, max = 300, value = 30, step = 5),
      sliderInput("delta", "True mean difference (mu_B - mu_A)",
                  min = -4, max = 4, value = 1, step = 0.1),
      sliderInput("sigma", "Population standard deviation (sigma)",
                  min = 0.25, max = 4, value = 1.5, step = 0.05),
      sliderInput("alpha", "Significance threshold (alpha)",
                  min = 0.01, max = 0.10, value = 0.05, step = 0.01),
      hr(),
      h4(class = "sidebar-title", "Compare statistical tests"),
      checkboxGroupInput(
        "extra_tests", "Show additional tests",
        choices = c("Wilcoxon rank-sum (Mann-Whitney)" = "wilcoxon",
                    "Kolmogorov-Smirnov (KS)" = "ks"),
        selected = "wilcoxon"
      ),
      p(class = "controls-note",
        "The t-test is always displayed. Wilcoxon compares ranks; KS detects ANY distributional difference. Under this normal-shift model, the tests address compatible null hypotheses, but the test statistics differ."),
      conditionalPanel(
        condition = "input.main_tabs == 'Single study & power'",
        checkboxInput("show_obs", "Show observed values in plot 1", TRUE),
        actionButton("resample", "Draw a new random sample", width = "100%")
      ),
      conditionalPanel(
        condition = "input.main_tabs == 'Repeated samples & CI coverage'",
        hr(),
        h4(class = "sidebar-title", "Repeated sampling"),
        selectInput("replicates", "Number of independent experiments",
                    choices = c(10, 20, 50, 100, 200, 500, 1000),
                    selected = 100),
        checkboxInput("show_all_ci",
                      "Show ALL intervals (makes the plot very tall)", FALSE),
        actionButton("rerun_coverage", "Draw a NEW batch of experiments",
                     width = "100%"),
        p(class = "controls-note",
          "Population sliders update both tabs. This button repeats the simulation with new random observations. The summary always uses ALL experiments, even if the plot shows only the first 100.")
      ),
      hr(),
      p(class = "controls-note",
        "Group A always has population mean 0. Group B has population mean mu_B = the selected mean difference. Both groups have the same sigma and n."),
      p(class = "controls-note",
        "Moving sliders keeps the underlying random draws fixed. Each tab has its own button to generate new random observations."),
      p(class = "controls-note",
        "All calculations run locally after the shiny package has been installed.")
    ),
    mainPanel(
      width = 9,
      tabsetPanel(
        id = "main_tabs",
        tabPanel(
          "Single study & power",
          uiOutput("metrics"),
          fluidRow(
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("population_plot", height = "310px"),
                  p(class = "chart-caption",
                    "Population distributions of individual observations. The gray region is their overlap. Changing n alone does not change either distribution."))
            ),
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("sampling_plot", height = "310px"),
                  p(class = "chart-caption",
                    "Sampling distributions of the estimated difference in means. Their width is determined by SE = sigma * sqrt(2/n), which shrinks when n increases."))
            )
          ),
          fluidRow(
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("pvalue_plot", height = "310px"),
                  p(class = "chart-caption",
                    "Student t distribution if H0 is true. Rose areas are outcomes at least as extreme as the observed |t|: together, their area is the two-sided p-value."))
            ),
            column(
              width = 6,
              div(class = "chart-panel",
                  plotOutput("power_plot", height = "310px"),
                  p(class = "chart-caption",
                    "The t-test curve is exact. Optional Wilcoxon power is a large-sample approximation and KS power is estimated by repeated simulations. Dots show the selected n."),
                  uiOutput("power_method_note"))
            )
          ),
          uiOutput("interpretation")
        ),
        tabPanel(
          "Repeated samples & CI coverage",
          uiOutput("coverage_metrics"),
          div(
            class = "chart-panel",
            uiOutput("ci_plot_ui"),
            div(class = "simulation-note", textOutput("ci_plot_context")),
            p(class = "simulation-note",
              tags$span(class = "legend-line", style = paste0("color:", col_A, ";"),
                        "Blue interval"), " = covers the true difference; ",
              tags$span(class = "legend-line", style = paste0("color:", col_B, ";"),
                        "orange interval"), " = misses the true difference. ",
              tags$span(class = "legend-line", style = paste0("color:", col_p, ";"),
                        "Filled rose dot"), " = statistically significant (p < alpha). ",
              "An open dot = not significant. Dashed violet line = true difference; ",
              "dotted gray line = null value (0)."
            )
          ),
          div(
            class = "chart-panel",
            plotOutput("running_rates_plot", height = "350px"),
            p(class = "chart-caption",
              "The running proportions of intervals covering the true effect and of significant tests. Across many new experiments, they should tend toward the confidence level and theoretical power, respectively.")
          ),
          p(class = "test-note",
            "The confidence-interval forest plot and its significance markers belong to the t-test for the MEAN difference. Wilcoxon and KS test results do not share these t-based confidence intervals."),
          uiOutput("coverage_interpretation")
        )
      )
    )
  )
)

server <- function(input, output, session) {

  # The base draws depend ONLY on the button, never on the sliders.
  # Generating the full 300 per group also keeps the first observations
  # identical as n is increased or decreased.
  standard_draws <- reactive({
    set.seed(20261123 + input$resample)
    list(A = rnorm(300), B = rnorm(300))
  })

  samples <- reactive({
    z <- standard_draws()
    n <- input$n
    sigma <- input$sigma
    list(
      A = sigma * z$A[seq_len(n)],
      B = input$delta + sigma * z$B[seq_len(n)]
    )
  })

  result <- reactive({
    s <- samples()
    test <- t.test(s$B, s$A,
                   alternative = "two.sided",
                   var.equal = TRUE,
                   conf.level = 1 - input$alpha)
    n <- input$n
    delta <- input$delta
    sigma <- input$sigma

    list(
      test = test,
      observed_diff = mean(s$B) - mean(s$A),
      theoretical_se = sigma * sqrt(2 / n),
      overlap = 2 * pnorm(-abs(delta) / (2 * sigma)),
      cohen_d = delta / sigma,
      power = power_two_sample(n, delta, sigma, input$alpha)
    )
  })

  # The observed p-value for every selected test is computed on the SAME
  # two samples as the t-test, not independently drawn data.
  extra_results <- reactive({
    chosen <- input$extra_tests
    if (length(chosen) == 0L) return(list())
    s <- samples()
    ans <- list()
    if ("wilcoxon" %in% chosen) {
      ans$wilcoxon <- wilcox.test(s$B, s$A,
                                  alternative = "two.sided",
                                  exact = FALSE, correct = FALSE)
    }
    if ("ks" %in% chosen) {
      ans$ks <- ks.test(s$B, s$A,
                        alternative = "two.sided", exact = FALSE)
    }
    ans
  })

  # The Wilcoxon curve is analytic (normal approximation). KS power is
  # estimated using Monte Carlo, and recomputed only when delta/sigma or
  # alpha changes (not on each n change or on the 'new sample' button).
  wilcoxon_powers <- reactive({
    req("wilcoxon" %in% input$extra_tests)
    wilcoxon_power_normal(5:300, input$delta, input$sigma, input$alpha)
  })

  ks_power_results <- reactive({
    req("ks" %in% input$extra_tests)
    d <- input$delta / input$sigma
    alpha <- input$alpha
    set.seed(20261127)
    za <- matrix(rnorm(ks_repetitions * 300L), nrow = ks_repetitions)
    zb <- matrix(rnorm(ks_repetitions * 300L), nrow = ks_repetitions)
    powers <- numeric(length(ks_sample_sizes))
    shiny::withProgress(message = "Estimating KS power by simulation", value = 0, {
      for (i in seq_along(ks_sample_sizes)) {
        ni <- ks_sample_sizes[i]
        rejected <- logical(ks_repetitions)
        for (j in seq_len(ks_repetitions)) {
          # Common affine scaling by sigma does not affect KS results.
          rejected[j] <- ks.test(zb[j, seq_len(ni)] + d,
                                 za[j, seq_len(ni)],
                                 alternative = "two.sided",
                                 exact = FALSE)$p.value < alpha
        }
        powers[i] <- mean(rejected)
        shiny::incProgress(1 / length(ks_sample_sizes))
      }
    })
    list(n = ks_sample_sizes, power = powers,
         repetitions = ks_repetitions)
  })

  ks_power_at_n <- reactive({
    x <- ks_power_results()
    as.numeric(approx(x = x$n, y = x$power,
                      xout = input$n, rule = 2)$y)
  })

  # Separate random numbers for the repeated-sampling experiment.
  # Keeping the underlying standard-normal draws fixed when sliders move
  # makes comparisons instructive. Clicking the button redraws the entire
  # batch. Drawing 1,000 x 300 values for EACH group is still lightweight.
  coverage_base_draws <- reactive({
    set.seed(20261124 + input$rerun_coverage)
    list(A = matrix(rnorm(1000 * 300), nrow = 1000, ncol = 300),
         B = matrix(rnorm(1000 * 300), nrow = 1000, ncol = 300))
  })

  coverage_results <- reactive({
    z <- coverage_base_draws()
    m <- as.integer(input$replicates)
    n <- input$n
    sigma <- input$sigma
    delta <- input$delta
    alpha <- input$alpha

    # Each row is a separate independent study, with n per group.
    a <- sigma * z$A[seq_len(m), seq_len(n), drop = FALSE]
    b <- delta + sigma * z$B[seq_len(m), seq_len(n), drop = FALSE]
    mean_a <- rowMeans(a)
    mean_b <- rowMeans(b)
    var_a <- rowSums((a - mean_a)^2) / (n - 1)
    var_b <- rowSums((b - mean_b)^2) / (n - 1)

    # Equal-n, pooled-variance, two-sided Student t-test.
    # Pooled variance: ((n-1)*var_a + (n-1)*var_b)/(2*n-2).
    pooled_var <- (var_a + var_b) / 2
    estimated_se <- sqrt(pooled_var * (2 / n))
    estimated_diff <- mean_b - mean_a
    degrees_of_freedom <- 2 * n - 2
    t_statistics <- estimated_diff / estimated_se
    p_values <- 2 * pt(-abs(t_statistics), df = degrees_of_freedom)
    t_critical <- qt(1 - alpha / 2, df = degrees_of_freedom)
    ci_lower <- estimated_diff - t_critical * estimated_se
    ci_upper <- estimated_diff + t_critical * estimated_se

    # Coverage and significance are DIFFERENT questions:
    # - Coverage: Does the CI contain the TRUE effect delta?
    # - Significance: Does the CI exclude the NULL value zero?
    # With delta=0 these correspond to complementary events.
    covered <- ci_lower <= delta & delta <= ci_upper
    significant <- p_values < alpha

    list(m = m, n = n, delta = delta, sigma = sigma, alpha = alpha,
         estimated_diff = estimated_diff, estimated_se = estimated_se,
         lower = ci_lower, upper = ci_upper, p_values = p_values,
         covered = covered, significant = significant,
         theoretical_power = power_two_sample(n, delta, sigma, alpha))
  })

  output$coverage_metrics <- renderUI({
    r <- coverage_results()
    div(
      class = "metric-grid",
      metric_card("Observed CI coverage",
                  sprintf("%.1f%%", 100 * mean(r$covered)),
                  sprintf("%d of %d CIs contain the true effect",
                          sum(r$covered), r$m), col_A),
      metric_card("Target CI coverage",
                  sprintf("%.1f%%", 100 * (1 - r$alpha)),
                  "Long-run confidence level"),
      metric_card("Significant results",
                  sprintf("%.1f%%", 100 * mean(r$significant)),
                  sprintf("%d of %d studies reject H0",
                          sum(r$significant), r$m), col_p),
      metric_card(if (r$delta == 0) "Expected type I error" else "Theoretical power",
                  sprintf("%.1f%%", 100 * r$theoretical_power),
                  if (r$delta == 0) "Expected false-positive rate" else
                    "Expected significant-result rate")
    )
  })

  output$ci_plot_ui <- renderUI({
    r <- coverage_results()
    count <- if (isTRUE(input$show_all_ci)) r$m else min(100L, r$m)
    plot_height <- max(380L, 9L * count + 100L)
    plotOutput("ci_plot", height = paste0(plot_height, "px"))
  })

  output$ci_plot_context <- renderText({
    r <- coverage_results()
    count <- if (isTRUE(input$show_all_ci)) r$m else min(100L, r$m)
    sprintf("Showing %d of %d studies. The summary statistics and running-rate plot use all %d studies. The confidence level is %.0f%% (alpha = %.2f).",
            count, r$m, r$m, 100 * (1 - r$alpha), r$alpha)
  })

  output$ci_plot <- renderPlot({
    r <- coverage_results()
    count <- if (isTRUE(input$show_all_ci)) r$m else min(100L, r$m)
    idx <- seq_len(count)
    x_range <- range(c(0, r$delta, r$lower[idx], r$upper[idx]))
    x_padding <- max(diff(x_range) * 0.06, r$sigma * 0.12)
    ylim_top <- count + 0.5

    plot_setup()
    par(mar = c(4.2, 4.5, 3, 0.9))
    plot(NA, xlim = c(x_range[1] - x_padding,
                      x_range[2] + x_padding),
         ylim = c(ylim_top, 0.5),
         xlab = "Estimated mean difference (group B - group A)",
         ylab = "Study sample (independent experiment)",
         yaxt = "n", bty = "l",
         main = sprintf("%.0f%% confidence intervals from repeated samples",
                        100 * (1 - r$alpha)))
    y_ticks <- pretty(c(1, count), n = 8)
    y_ticks <- y_ticks[y_ticks >= 1 & y_ticks <= count]
    axis(2, at = y_ticks, labels = y_ticks, las = 1)
    abline(v = 0, col = col_null, lty = 3, lwd = 2)
    abline(v = r$delta, col = col_true, lty = 2, lwd = 2)

    # CI color shows coverage; point fill shows significance.
    segments(r$lower[idx], idx, r$upper[idx], idx,
             col = ifelse(r$covered[idx], col_A, col_B), lwd = 2.0)
    not_significant <- idx[!r$significant[idx]]
    significant <- idx[r$significant[idx]]
    points(r$estimated_diff[not_significant], not_significant,
           pch = 1, col = col_null, cex = 0.68)
    points(r$estimated_diff[significant], significant,
           pch = 21, col = col_p, bg = col_p, cex = 0.68)
  }, res = 110)

  output$running_rates_plot <- renderPlot({
    r <- coverage_results()
    k <- seq_len(r$m)
    coverage_rate <- cumsum(r$covered) / k
    significance_rate <- cumsum(r$significant) / k

    plot_setup()
    plot(k, coverage_rate, type = "l", col = col_A, lwd = 2.5,
         ylim = c(0, 1), xlab = "Number of experiments", 
         ylab = "Cumulative proportion", bty = "l",
         main = "How observed proportions stabilize")
    lines(k, significance_rate, col = col_p, lwd = 2.5)
    abline(h = 1 - r$alpha, col = col_A, lty = 3, lwd = 1.5)
    abline(h = r$theoretical_power, col = col_p, lty = 3, lwd = 1.5)
    legend("right",
           legend = c("Observed CI coverage", "Expected CI coverage",
                      "Observed significant results", "Expected significance rate"),
           col = c(col_A, col_A, col_p, col_p),
           lty = c(1, 3, 1, 3), lwd = c(2.4, 1.4, 2.4, 1.4),
           bg = "white", cex = 0.77)
  })

  output$coverage_interpretation <- renderUI({
    r <- coverage_results()
    n_covers <- sum(r$covered)
    n_significant <- sum(r$significant)
    div(
      class = "explain-panel",
      h4("Interpretation: coverage is not significance"),
      p(sprintf("In %d independent simulated studies, %d (%.1f%%) confidence intervals contained the true population difference of %.2f. The confidence level is %.0f%%, so the expected long-run coverage is %.0f%%.",
                r$m, n_covers, 100 * n_covers / r$m, r$delta,
                100 * (1 - r$alpha), 100 * (1 - r$alpha))),
      p(sprintf("In %d studies (%.1f%%), the null hypothesis of zero difference was rejected (p < %.2f). The theoretical rejection probability is %.1f%%.",
                n_significant, 100 * n_significant / r$m,
                r$alpha, 100 * r$theoretical_power)),
      p(if (r$delta == 0) {
        "Here the true effect equals the null value. Every significant result is a false positive, and its confidence interval necessarily misses the true effect. The theoretical false-positive probability is alpha."
      } else {
        "The true effect is not zero: an interval can contain the TRUE effect and still EXCLUDE zero (significant), or miss the true effect and nevertheless INCLUDE zero (not significant). Coverage and statistical significance measure different properties."
      }),
      tags$hr(),
      p(tags$b("Why does the observed proportion vary? "),
        "Each independent experiment samples new observations. Even a procedure with exact theoretical coverage of, for example, 95% does not have to cover the true effect in exactly 95 of 100 studies. Running more experiments makes the observed rates typically more stable."),
      p(tags$b("Why use t intervals instead of +/- 1.96 SE? "),
        "The population SD is treated as unknown in each study. The pooled-variance Student t-test and its matching t-based confidence interval use the estimated standard error and 2n-2 degrees of freedom, preserving the correspondence between p-values and confidence intervals.")
    )
  })

  output$metrics <- renderUI({
    r <- result()
    significant <- r$test$p.value < input$alpha
    tags$div(
      class = "metric-grid",
      metric_card("Observed p-value", format_p(r$test$p.value),
                  if (significant) "p < alpha (significant)" else "p >= alpha (not significant)",
                  if (significant) col_p else col_null),
      metric_card("Student t-test power", sprintf("%.1f%%", 100 * r$power),
                  "Exact power under the normal model"),
      metric_card("Population overlap", sprintf("%.1f%%", 100 * r$overlap),
                  "Shared area under the individual-level curves"),
      metric_card("Theoretical SE", sprintf("%.3f", r$theoretical_se),
                  "SE of the difference in sample means"),
      metric_card("Observed mean difference", sprintf("%+.3f", r$observed_diff),
                  "Sample mean B minus sample mean A"),
      metric_card("True Cohen's d", sprintf("%+.2f", r$cohen_d),
                  "Population difference divided by sigma")
    )
  })

  output$population_plot <- renderPlot({
    s <- samples()
    delta <- input$delta
    sigma <- input$sigma
    x <- seq(min(0, delta) - 4.2 * sigma,
             max(0, delta) + 4.2 * sigma, length.out = 650)
    yA <- dnorm(x, mean = 0, sd = sigma)
    yB <- dnorm(x, mean = delta, sd = sigma)
    ymax <- max(yA, yB)

    plot_setup()
    plot(x, yA, type = "n",
         ylim = c(if (input$show_obs) -0.14 * ymax else 0, 1.13 * ymax),
         xlab = "Individual measurement", ylab = "Density",
         main = "1  Population distributions")
    polygon(c(x, rev(x)),
            c(pmin(yA, yB), rep(0, length(x))),
            col = adjustcolor(col_null, alpha.f = 0.20), border = NA)
    lines(x, yA, col = col_A, lwd = 2.6)
    lines(x, yB, col = col_B, lwd = 2.6)
    abline(v = c(0, delta), col = c(col_A, col_B), lty = 3)

    if (input$show_obs) {
      # Deterministic vertical offsets prevent exact overplotting.
      points(s$A, -(0.045 + (seq_along(s$A) %% 6) * 0.012) * ymax,
             pch = 16, cex = 0.40, col = adjustcolor(col_A, 0.40))
      points(s$B, -(0.045 + (seq_along(s$B) %% 6) * 0.012) * ymax,
             pch = 16, cex = 0.40, col = adjustcolor(col_B, 0.40))
    }
    legend("topright", c("Group A", "Group B"),
           col = c(col_A, col_B), lwd = 2.5, bty = "n", cex = 0.85)
  })

  output$sampling_plot <- renderPlot({
    r <- result()
    delta <- input$delta
    se <- r$theoretical_se
    x <- seq(min(0, delta) - 4.2 * se,
             max(0, delta) + 4.2 * se, length.out = 650)
    h0 <- dnorm(x, 0, se)
    h1 <- dnorm(x, delta, se)

    plot_setup()
    plot(x, h0, type = "n", ylim = c(0, max(h0, h1) * 1.13),
         xlab = "Estimated difference in means (B - A)", ylab = "Density",
         main = "2  Sampling variability")
    lines(x, h0, col = col_null, lwd = 2.6)
    lines(x, h1, col = col_B, lwd = 2.6)
    abline(v = r$observed_diff, lty = 2, lwd = 1.8, col = col_p)
    legend("topright",
           legend = c("If H0 is true", "If selected difference is true",
                      "Observed estimate"),
           col = c(col_null, col_B, col_p), lty = c(1, 1, 2),
           lwd = c(2.5, 2.5, 1.8), bty = "n", cex = 0.77)
  })

  output$pvalue_plot <- renderPlot({
    r <- result()
    t_obs <- abs(unname(r$test$statistic))
    df <- unname(r$test$parameter)
    critical <- qt(1 - input$alpha / 2, df = df)
    limit <- max(4.2, min(10, t_obs + 0.8))
    x <- seq(-limit, limit, length.out = 850)
    density <- dt(x, df = df)

    plot_setup()
    plot(x, density, type = "n", ylim = c(0, max(density) * 1.17),
         xlab = "t statistic under H0", ylab = "Density",
         main = "3  Two-sided p-value")

    if (t_obs < limit) {
      xx_left <- seq(-limit, -t_obs, length.out = 200)
      xx_right <- seq(t_obs, limit, length.out = 200)
      polygon(c(xx_left[1], xx_left, tail(xx_left, 1)),
              c(0, dt(xx_left, df), 0),
              col = adjustcolor(col_p, 0.32), border = NA)
      polygon(c(xx_right[1], xx_right, tail(xx_right, 1)),
              c(0, dt(xx_right, df), 0),
              col = adjustcolor(col_p, 0.32), border = NA)
      abline(v = c(-t_obs, t_obs), col = col_p, lty = 2, lwd = 1.6)
    }

    lines(x, density, col = col_null, lwd = 2.3)
    abline(v = c(-critical, critical), lty = 3,
           col = col_B, lwd = 1.5)
    legend("topright",
           legend = c("Null distribution", "Observed |t| (p-value tails)",
                      "Critical values (+/-)"),
           col = c(col_null, col_p, col_B),
           lty = c(1, 2, 3), lwd = c(2.4, 1.7, 1.5),
           bty = "n", cex = 0.74)
    if (t_obs >= limit) {
      mtext("Observed |t| lies beyond the plotted range", side = 1,
            line = 3.2, cex = 0.66, col = col_p)
    }
  })

  output$power_plot <- renderPlot({
    r <- result()
    ns <- 5:300
    powers <- power_two_sample(ns, input$delta, input$sigma, input$alpha)

    chosen <- input$extra_tests
    # Read these conditionally: no Monte Carlo computation if KS is not shown.
    wilcox_curve <- if ("wilcoxon" %in% chosen) wilcoxon_powers() else NULL
    ks_curve <- if ("ks" %in% chosen) ks_power_results() else NULL

    plot_setup()
    plot(ns, powers, type = "l", lwd = 2.8, col = col_A,
         ylim = c(0, 1), xlim = range(ns),
         xlab = "Sample size per group (n)", ylab = "Probability of p < alpha",
         main = "4  Compare statistical power")
    abline(h = 0.8, col = col_B, lty = 3, lwd = 1.5)
    abline(h = input$alpha, col = col_null, lty = 3, lwd = 1.2)
    abline(v = input$n, col = adjustcolor(col_null, 0.38), lty = 2)

    leg_text <- c("Student t (exact)")
    leg_col <- c(col_A)
    leg_lty <- c(1)
    if (!is.null(wilcox_curve)) {
      lines(ns, wilcox_curve, col = col_wilcox, lwd = 2.5, lty = 2)
      points(input$n, wilcox_curve[input$n - 4L],
             pch = 19, col = col_wilcox, cex = 1.18)
      leg_text <- c(leg_text, "Wilcoxon (approx.)")
      leg_col <- c(leg_col, col_wilcox)
      leg_lty <- c(leg_lty, 2)
    }
    if (!is.null(ks_curve)) {
      lines(ks_curve$n, ks_curve$power, col = col_ks, lwd = 2.3)
      points(ks_curve$n, ks_curve$power, col = col_ks,
             pch = 16, cex = 0.40)
      points(input$n,
             approx(ks_curve$n, ks_curve$power, xout = input$n)$y,
             pch = 19, col = col_ks, cex = 1.18)
      leg_text <- c(leg_text, "KS (Monte Carlo)")
      leg_col <- c(leg_col, col_ks)
      leg_lty <- c(leg_lty, 1)
    }
    points(input$n, r$power, pch = 19, cex = 1.35, col = col_A)
    legend("bottomright", legend = c(leg_text, "80% reference", "Alpha"),
           col = c(leg_col, col_B, col_null),
           lty = c(leg_lty, 3, 3),
           lwd = c(rep(2.5, length(leg_text)), 1.5, 1.2),
           bty = "n", cex = 0.76, bg = "white")
  })

  output$power_method_note <- renderUI({
    chosen <- input$extra_tests
    p(class = "test-note",
      "Exact t power (noncentral t distribution).",
      if ("wilcoxon" %in% chosen)
        " Wilcoxon: approximate rank-sum power using normal moments under the selected normal-shift model.",
      if ("ks" %in% chosen)
        sprintf(" KS: Monte Carlo estimate from %d repetitions per grid point; the jaggedness reflects simulation error. Intermediate n values are interpolated.",
                ks_repetitions),
      " Non-parametric tests are NOT universally less powerful."
    )
  })

  output$interpretation <- renderUI({
    r <- result()
    test <- r$test
    extras <- extra_results()
    alpha <- input$alpha
    ci <- unname(test$conf.int)

    # Show the selected tests in parallel columns. A t confidence interval
    # estimates the difference in means; a KS test cannot be assigned it.
    labels <- c("Student t-test")
    hypotheses <- c("Equal population means (under equal-variance normality)")
    stats <- c(sprintf("t = %.3f; df = %.0f",
                       unname(test$statistic), unname(test$parameter)))
    p_values <- c(test$p.value)
    power_labels <- c(sprintf("%.1f%% (exact)", 100 * r$power))
    ci_labels <- c(sprintf("[%.3f, %.3f] (mean difference)", ci[1], ci[2]))

    if (!is.null(extras$wilcoxon)) {
      w <- extras$wilcoxon
      labels <- c(labels, "Wilcoxon rank-sum")
      hypotheses <- c(hypotheses,
        "Equal distributions; for the selected equal-shape normal populations, a location difference")
      stats <- c(stats, sprintf("W = %.1f", unname(w$statistic)))
      p_values <- c(p_values, w$p.value)
      power_labels <- c(power_labels, sprintf("%.1f%% (approx.)",
                         100 * wilcoxon_powers()[input$n - 4L]))
      ci_labels <- c(ci_labels, "Not a CI for the mean difference")
    }
    if (!is.null(extras$ks)) {
      k <- extras$ks
      labels <- c(labels, "Kolmogorov-Smirnov")
      hypotheses <- c(hypotheses,
        "Equal distributions (any difference in their CDFs, not specifically means)")
      stats <- c(stats, sprintf("D = %.3f", unname(k$statistic)))
      p_values <- c(p_values, k$p.value)
      power_labels <- c(power_labels, sprintf("%.1f%% (MC, interpolated)",
                          100 * ks_power_at_n()))
      ci_labels <- c(ci_labels, "Not a CI for the mean difference")
    }

    decision <- ifelse(p_values < alpha,
                       "Reject H0 (significant)",
                       "Do not reject H0")
    row_ui <- function(header, cells) {
      tags$tr(tags$th(scope = "row", header),
              lapply(cells, tags$td))
    }

    div(class = "explain-panel",
      h4("How to interpret the SAME observed sample using different tests"),
      div(class = "test-table-wrap",
        tags$table(class = "test-table",
          tags$thead(tags$tr(
            tags$th(scope = "col", "Measure"),
            lapply(seq_along(labels), function(i)
              tags$th(scope = "col", class = "test-col", labels[i]))
          )),
          tags$tbody(
            row_ui("Null hypothesis", hypotheses),
            row_ui("Test statistic", stats),
            row_ui("Two-sided p-value", vapply(p_values, format_p, character(1))),
            row_ui(sprintf("Decision at alpha = %.2f", alpha), decision),
            row_ui("Power at selected n", power_labels),
            row_ui(sprintf("%.0f%% CI", 100 * (1 - alpha)), ci_labels)
          )
        )
      ),
      p(sprintf("Observed difference in sample means (B - A): %.3f. The true difference used to generate the data is %.3f.",
                r$observed_diff, input$delta)),
      p("Every p-value in this table comes from the same two samples. A significant result supports rejecting that test's null hypothesis; a non-significant result does not demonstrate equality."),
      p("The pooled t confidence interval and its exact coverage apply only to the MEAN difference under the model assumptions. Neither Wilcoxon nor KS automatically provides an equivalent mean-difference confidence interval."),
      if (!is.null(extras$wilcoxon)) p(
        tags$b("Wilcoxon: "),
        "The rank-sum test detects a shift in stochastic ordering. Under equal-shape distributions, it can be interpreted as a location comparison. Its two-sided p-value here uses a normal approximation without continuity correction."),
      if (!is.null(extras$ks)) p(
        tags$b("KS: "),
        "The two-sample KS test detects differences anywhere in the cumulative distributions. It is an omnibus test, not a specifically targeted mean test; its p-value here uses an asymptotic distribution."),
      tags$hr(),
      p(tags$b("Important: "),
        "The t-test is generally more efficient under this normal, equal-variance model, but a rank-based test can be MORE powerful for some heavy-tailed distributions. The difference between tests is often much smaller than students expect."),
      p("The observed p-value is calculated under a null hypothesis. Power is the long-run probability of obtaining p < alpha under the specified true population model. Neither p nor power is the probability that H0 is true.")
    )
  })
}

shinyApp(ui = ui, server = server)
