# Understanding Statistical Tests, Effect Sizes and Power

**Student guide to the interactive R Shiny app**  
*Independent continuous outcomes · repeated studies and confidence intervals · independent binary outcomes · paired binary outcomes · comparing variances*

This guide accompanies `app.R` (the *Statistical testing teaching app*, version 5). It is intended for self-study and for use during an introductory or intermediate statistics course. You do not need to understand the R source code to use the app.

The app lets you choose the **true characteristics of simulated populations**, draw random samples, apply statistical tests, and observe how conclusions vary across studies. In real research, these population characteristics are usually unknown. Here, knowing the truth makes it possible to see exactly what statistical inference can and cannot tell us.

## 1. Learning goals

By the end of the exercises, you should be able to:

1. distinguish a **population parameter**, a **sample estimate**, and the **sampling distribution** of an estimate;
2. explain why sample size, variability, effect size, and the significance threshold influence statistical results;
3. interpret a p-value, statistical power, Type I error, and confidence interval coverage correctly;
4. distinguish tests of **means**, **distributions**, **proportions**, **paired changes**, and **variances**;
5. explain why a statistically significant result is not necessarily large or important; and
6. recognize why the **study design and test assumptions** matter as much as the observed p-value.

### Run the app

Save the app source as `app.R`. In R or RStudio, set the working directory to the folder containing the file and run:

```r
install.packages("shiny")  # once, if not already installed
shiny::runApp("app.R")
```

The only required R package is **shiny**. Once installed, the app's simulations and graphics can run without an internet connection. Some settings, especially the Kolmogorov–Smirnov (KS) power simulation, take longer to calculate.

## 2. The statistical story behind all five tabs

Imagine two populations, A and B. You can specify properties of both populations, such as their means, standard deviations, or probabilities of a binary outcome. The program then draws **samples** from those populations, as a researcher would collect observations from patients or study participants.

| Concept | Meaning in this app | Key question |
| --- | --- | --- |
| True parameter | A population quantity selected with a slider (e.g., a true mean difference). | What is actually true? |
| Estimate | A quantity calculated from the sampled observations (e.g., the observed difference in means). | What did this particular study find? |
| Standard error (SE) | Variation in an estimator across repeated random samples. | How much do estimates fluctuate? |
| Null hypothesis ($H_0$) | The proposition evaluated by a statistical test. | Which statement is the test assessing? |
| p-value | Under $H_0$ and the test assumptions, the probability of a test statistic at least as extreme as the observed one. | How surprising is the result under $H_0$? |
| Significance level ($\alpha$) | A preselected rejection threshold (default: 0.05). | When will we reject $H_0$? |
| Statistical power | Probability of rejecting $H_0$ when the relevant alternative is true. | How often will this design detect the specified difference? |
| Type I error | Rejection of a true null hypothesis. | How often will we get a false positive? |
| Confidence interval (CI) | An interval produced by a procedure designed to cover a fixed parameter at a stated long-run rate. | How precise is the estimate? |

**Three quantities must not be confused:** the p-value from *one observed study*, the *long-run probability of rejecting* the null, and the *long-run probability that a CI covers the true parameter*. The app illustrates all three.

### Map of the app

| Tab | Data structure | Main question |
| --- | --- | --- |
| **Single study & power** | Two independent groups, continuous outcomes | How do a sample, p-value, effect size, and power relate? |
| **Repeated samples & CI coverage** | Many independent two-group studies | How do estimates and confidence intervals vary from study to study? |
| **Independent 2x2: chi-square** | Two independent groups, Yes/No outcomes | Are the population proportions equal? |
| **McNemar: paired outcomes** | Two binary responses from each person | Are changes in the two directions equally likely? |
| **F-test: equal variances** | Two independent normal groups | Are the population variances equal? |

### Controls you will see repeatedly

- **Significance threshold (alpha):** varies from 0.01 to 0.10 and starts at 0.05. Smaller alpha means stronger evidence is required to reject $H_0$. When a t-based confidence interval is shown, its confidence level is $1-\alpha$ (e.g., 95% at alpha = 0.05).
- **Sample size:** increases the amount of data, usually reducing estimation uncertainty and increasing power for a fixed nonzero effect. Its interpretation differs by tab: *per group*, *per group separately*, or *number of pairs*.
- **Draw a new sample / batch:** generates a new random realization under the current model. A p-value is not a fixed property of the populations: it changes from sample to sample.
- **Power/rejection curves:** show probabilities across hypothetical sample sizes; they are not the results of one study. Where curves come from simulation, small irregularities are Monte Carlo variation.

**An important design feature:** The app reuses underlying random draws when you move sliders, allowing a relatively controlled comparison of settings. A “Draw new…” button changes the random realization. Even with fixed underlying draws, changing sample size changes which observations are included. Do not interpret a change after moving a slider as a perfectly controlled scientific experiment; it is a teaching visualization.

## 3. Tab 1 — Single study & power

**Purpose:** Understand how one observed result arises from two populations and how often a chosen test would reject the null across many repetitions.

The data are independent normally distributed measurements. Population A has mean $\mu_A=0$; population B has mean $\mu_B=\Delta$. Therefore the **true mean difference** is $\Delta=\mu_B-\mu_A$. By default, the groups have 30 observations each, $\Delta=1$, and a population standard deviation of 1.5 in both groups.

### 3.1 What do the settings mean?

| Setting (initial value) | Definition | What happens when you increase it? |
| --- | --- | --- |
| **Sample size, group A** ($n_A=30$) | Number of observations in A. | Usually reduces the SE of the mean difference and increases power. |
| **Sample size, group B** ($n_B=30$) | Number of observations in B. | Same principle; an extreme imbalance can be inefficient. |
| **True mean difference** ($\Delta=1$) | Population mean B minus population mean A. Negative values mean B is lower. | Moves B's population curve to the right and generally increases power as $|\Delta|$ grows. |
| **Population SD, group A** ($\sigma_A=1.5$) | True individual-level spread in A. | Widens A's population distribution and usually increases the SE. |
| **Population SD, group B** ($\sigma_B=1.5$) | True individual-level spread in B. | Widens B's distribution and usually increases the SE. |
| **Show observed values in plot 1** (on) | Displays the individual sampled measurements below the population curves. | Does not change any statistical calculation. |
| **Draw a new random sample** | Generates another observed dataset from the chosen populations. | The observed difference and p-values may change even though the truth is unchanged. |
| **Also show Student's pooled t-test** (off) | Adds the t-test that assumes equal population variances. | Lets you compare inference with Welch on exactly the same data. |
| **Nonparametric comparisons** (Wilcoxon selected; KS optional) | Adds rank-sum and/or distribution-comparison tests. | Shows that different tests address different hypotheses. |

### 3.2 The four graphs

**Graph 1 — Population distributions.** The blue and amber curves describe the *individual measurements* in populations A and B. The grey shaded region is the **overlap of their probability densities**: substantial overlap is possible even if the means differ. Small dots show observations from the current sample when enabled. Increasing sample size adds dots but **does not change the population curves**.

**Graph 2 — Sampling variability.** These curves describe the **estimated difference between group means across repeated studies**, not individual measurements. The grey curve is centered at zero if the null hypothesis is true; the amber curve is centered at the selected true difference. The dashed rose line marks the mean difference in the **current sample**. Under this normal-data model, the true sampling SE is

$$
\operatorname{SE}(\bar X_B-\bar X_A)=\sqrt{\frac{\sigma_A^2}{n_A}+\frac{\sigma_B^2}{n_B}}.
$$

If you increase the group sizes while holding the population SDs fixed, these curves become narrower. This is why larger studies can detect smaller effects. **The width of a population distribution is not the same as the uncertainty in a sample mean.**

**Graph 3 — Welch two-sided p-value.** The grey t-density is an *approximate reference distribution under $H_0$*. The observed Welch t-statistic is compared with that reference. The rose tails correspond to results at least as extreme as the observed statistic **in either direction**; their combined probability is the p-value. The vertical dotted boundaries show the critical values determined by alpha. A p-value does **not** represent the probability that $H_0$ is true.

**Graph 4 — Rejection rates / statistical power.** The horizontal axis is **total sample size**, $N=n_A+n_B$, not sample size per group. Along the curve, the allocation ratio $n_A:n_B$ is held approximately constant; the dot marks the exact selected design. The blue Welch curve gives the simulated probability of $p<\alpha$. If $\Delta\neq0$, it represents power for testing equality of means. If $\Delta=0$, it represents the **null rejection rate**, interpreted as the Type I error rate for the mean-equality test. The dotted horizontal references mark 80% power and the selected alpha level. Optional curves show Student, Wilcoxon, and KS results.

### 3.3 The summary cards and comparison table

- **Welch p-value:** evidence against equal population means from the *current sample* (conditional on assumptions).
- **Welch rejection probability:** long-run probability of rejecting the equal-means null at the *selected design*, estimated by simulation.
- **Population overlap:** proportion of density shared by the two individual-level population curves (100% means identical densities).
- **True SE of mean difference:** expected sample-to-sample variation of the estimator under the specified population model; it is not an observed p-value.
- **Observed mean difference:** the current sample mean of B minus that of A; generally not identical to the true $\Delta$.
- **Standardized true difference:** $\Delta/\sqrt{(\sigma_A^2+\sigma_B^2)/2}$, a population-scale standardized effect. It is not the observed sample Cohen's $d$.

The comparison table lists each selected test's null hypothesis, test statistic, p-value, rejection decision, rejection probability, and (for the t-tests) a CI for the mean difference. Welch and Student are applied to exactly the same observations. The **separate Type I error experiment** at the bottom deliberately simulates equal population means ($\Delta=0$) while keeping your group sizes and SDs, regardless of the current delta slider. It helps reveal when Student's equal-variance assumption causes a distorted false-positive rate.

### 3.4 Why different tests can disagree

| Method | Main null hypothesis | Important distinction |
| --- | --- | --- |
| **Welch two-sample t-test** | $\mu_A=\mu_B$ | Allows different group variances; useful default for independent continuous outcomes. |
| **Student pooled two-sample t-test** | $\mu_A=\mu_B$ | Uses a common (pooled) variance estimate; its standard reference distribution assumes equal population variances. |
| **Wilcoxon rank-sum (Mann–Whitney)** | Equal population distributions (usual reference null) | Based on ranks; it is **not automatically a test of mean equality or a generic test of medians**. |
| **Two-sample Kolmogorov–Smirnov (KS)** | Equal population cumulative distributions | Can respond to differences in location, spread, or shape, not only means. |

If $\Delta=0$ but the SDs differ, the two population **means** are equal while their **distributions** are different. Therefore, a KS rejection can represent a genuine distributional difference, not a false positive for its own null hypothesis. Wilcoxon also needs care under unequal distribution shapes/scales and unbalanced group sizes: its usual reference distribution relies on stronger assumptions than just equal means. **Never choose a test after inspecting which one produces the smallest p-value.**

### Try it yourself — Experiments 1–4

**Experiment 1: More data, same populations.** Set $\Delta=1$, $\sigma_A=\sigma_B=1.5$, and $n_A=n_B=10$. Note the population overlap, theoretical SE, and Welch power. Then increase both group sizes to 100. *Predict:* Which population curves will change? Which sampling distribution will narrow? What happens to power? What might happen to the current p-value?

**Experiment 2: A true null hypothesis.** Set $\Delta=0$, keep equal SDs, and set $n_A=n_B=30$. Draw several new samples. *Observe:* Some estimated differences are positive, others negative; occasionally a p-value will be below 0.05. Compare the power graph and the separate Type I error panel. *Question:* Why does a 5% rejection probability not mean 5% of null hypotheses are true?

**Experiment 3: Equal means, different spreads.** Set $\Delta=0$, $\sigma_A=1$, $\sigma_B=3$ and, for a clearer comparison, $n_A=30$, $n_B=150$. Enable Student and KS. Examine the curves and the separate Type I error experiment. *Question:* Which hypotheses are actually true? Why is a KS rejection different from an invalid rejection of an equal-means null? Repeat with the sample sizes swapped.

**Experiment 4: Magnitude versus significance.** Keep both SDs at 1.5, set a small nonzero $\Delta=0.2$, and increase both sample sizes. *Question:* Can a small effect become statistically detectable? Does statistical significance establish practical or clinical importance?

## 4. Tab 2 — Repeated samples & CI coverage

**Purpose:** Replace the story of a single dataset with the long-run behavior of many independent studies. This tab uses the **same continuous-population settings** as Tab 1.

### 4.1 Controls

- **Number of independent experiments:** 10, 20, 50, 100, 200, 500, or 1000; initially 100. Every experiment draws a new independent sample from each of the specified populations.
- **Show ALL intervals:** shows up to 1000 intervals, which can create a very tall figure. Without this setting, at most the first 100 intervals are shown; the summary rates still use **all** simulated studies.
- **Draw a NEW batch of experiments:** changes the random realization of the batch. The observed coverage percentage may vary between batches.
- **Also show Student's pooled t-test:** overlays Student's intervals for the **same studies**. This is a fair comparison of the two methods.
- **Alpha:** also changes the corresponding t confidence level. At alpha = 0.05, these are 95% CIs; at alpha = 0.01, 99% CIs.

### 4.2 How to read the two graphs

**Confidence interval plot:** Each row is one independent study. The horizontal interval estimates the population **mean difference** $\Delta$. The **violet dashed vertical line** is the fixed true difference; the **grey dotted vertical line** is the null value zero. A **blue interval** contains the true difference; an **orange interval** misses it. A **filled rose point** indicates that study rejected the mean-equality null at the selected alpha; an **open point** indicates that it did not. If Student is enabled, its dashed interval appears just below the solid Welch interval in the same row.

Two different questions are being answered: **Does the CI contain the true $\Delta$?** (coverage) and **Does the CI exclude zero?** (significance). When $\Delta\neq0$, one interval can **both contain the true effect and exclude zero**. When $\Delta=0$, the true value and null coincide, so a CI that misses zero also produces a significant result for the corresponding two-sided t-test.

**Running rates plot:** The lines show cumulative proportions as more studies are included: the proportion of intervals covering the true $\Delta$ and the proportion of studies rejecting $H_0$. Dotted reference lines show **nominal confidence level** and separately simulated expected rejection probabilities. With few experiments, observed proportions fluctuate strongly; with many, they often stabilize. The observed coverage of 100 simulated 95% CIs does not have to equal exactly 95%.

### 4.3 What 95% confidence really means

Under a well-calibrated procedure and its assumptions, **95% of the intervals produced over repeated independent studies will contain the fixed true parameter in the long run**. After observing a particular classical 95% CI, we do not normally interpret it as a 95% posterior probability that the fixed parameter lies within those particular endpoints.

Confidence level and power are also different. A method can achieve approximately 95% CI coverage yet have low power to detect a small nonzero effect. Larger samples usually produce **narrower intervals**. An interval excluding zero indicates statistical significance at the corresponding two-sided alpha, but does not guarantee a substantively important effect.

### Try it yourself — Experiments 5–6

**Experiment 5: CI coverage under the true null.** Choose $\Delta=0$, equal SDs, and alpha = 0.05. Simulate 20 studies, then 1000. Compare the percentages of significant results and intervals covering the truth. *Question:* Why are the two percentages approximately complementary in this setting? Click “Draw a NEW batch” and look for Monte Carlo variation.

**Experiment 6: An incorrect equal-variance assumption.** Set $\sigma_A=1$, $\sigma_B=3$, $n_A=30$, $n_B=150$, and enable Student. Use 500 or 1000 studies. Compare Welch and Student coverage and rejection, first for $\Delta=0$, then for $\Delta=1$. *Question:* Which method better preserves its nominal confidence level under this simulated model? What changes when the true mean difference is nonzero?

## 5. Tab 3 — Independent 2x2: chi-square

**Purpose:** Study two **independent groups** with a binary outcome such as treatment success (Yes/No). There are $n$ different participants in each group. The initial settings are $n=30$, $P(\text{Yes}\mid A)=0.35$, and $P(\text{Yes}\mid B)=0.60$.

### 5.1 Controls and quantities

| Control or output | Meaning |
| --- | --- |
| **Observations per group (n)** | Number of *independent* people in A and also in B; total $N=2n$. |
| **True P(Yes) in group A** | Population probability of Yes for group A. |
| **True P(Yes) in group B** | Population probability of Yes for group B. |
| **Draw new independent groups** | Repeats the sampling of two independent groups. |
| **True risk difference** | $P(\text{Yes}\mid B)-P(\text{Yes}\mid A)$; initially $0.60-0.35=0.25$ (25 percentage points). |
| **Phi (signed)** | Association measure for a 2×2 table; its sign depends on the row and column coding. |
| **Cramer's V** | Nonnegative association strength. For a 2×2 table, $V=|\phi|$. |

The null hypothesis is **equal population proportions**, $P(\text{Yes}\mid A)=P(\text{Yes}\mid B)$. In the app, this is evaluated using Pearson's chi-square test, both **without** and **with Yates' continuity correction**. The correction generally makes the test more conservative; the two methods analyze the *same* observed table.

### 5.2 The four displays

1. **Observed 2×2 table:** Counts of Yes and No in each independent group. Note that sample proportions need not equal population probabilities.
2. **Observed and true proportions:** Bar heights show observed Yes proportions; crosses mark the true probabilities selected by the sliders.
3. **Chi-square null reference:** A chi-square distribution with one degree of freedom is the approximate reference under $H_0$. Vertical lines show the observed Pearson and Yates-corrected statistics.
4. **Power: Pearson vs. Yates correction:** Simulated rejection probabilities as **sample size per group** increases. The dotted 80% and alpha reference lines help with interpretation.

A small expected cell count weakens the usual large-sample chi-square approximation. The app warns if the smallest expected count is below 5. **Fisher's exact test is a common alternative, but it is not implemented in this tab.** If the observed table has no outcome variation (one outcome column is empty), the app cannot compute the usual chi-square or phi/V statistics and reports this instead.

**Important:** Phi and Cramer's V describe the *strength of association*, not the probability that the null hypothesis is true. With the app's ordering (rows A, B; columns Yes, No), **positive phi means a higher Yes proportion in A**, whereas the displayed risk difference is **B minus A**. Do not compare their signs without checking the coding.

### Try it yourself — Experiment 7

Set both probabilities to 0.50, then draw several new independent groups. Compare the sample proportions and p-values. Next, keep $P(\text{Yes}\mid A)=0.50$ and set $P(\text{Yes}\mid B)=0.70$. Increase $n$ from 10 to 200. *Questions:* Why might a single study fail to detect a real 20-percentage-point difference? Why is the risk difference conceptually different from Cramer's V? When are approximate chi-square p-values least reliable?

## 6. Tab 4 — McNemar: paired outcomes

**Purpose:** Analyze **paired binary outcomes**, such as Yes/No responses from the **same person** before and after an intervention. Here, $n$ means the **number of people/pairs**, not the sample size in two separate independent groups.

### 6.1 The four kinds of pairs

| Response at A | Response at B | Name | Entered in McNemar test? |
| --- | --- | --- | --- |
| No | No | Concordant | No |
| No | Yes | Discordant: No → Yes | **Yes** |
| Yes | No | Discordant: Yes → No | **Yes** |
| Yes | Yes | Concordant | No |

McNemar's null hypothesis is **equal probabilities of the two discordant directions**:

$$
H_0:\ P(A=\text{No}, B=\text{Yes})=P(A=\text{Yes}, B=\text{No}).
$$

This is a test of **marginal homogeneity** for paired binary responses, not an independent-samples chi-square test.

### 6.2 What do the three probability sliders control?

| Slider (initial value) | Interpretation | If you increase it… |
| --- | --- | --- |
| **Probability of a discordant pair** ($q=0.30$) | Fraction of all people expected to switch between Yes and No. | There are usually more informative switches; with the same directional imbalance, power often increases. |
| **P(A No, B Yes \| discordant)** ($r=0.70$) | Among switchers, the fraction expected to move from No to Yes. | More switches favor No → Yes; $r=0.50$ is the null balance. |
| **P(both Yes \| concordant)** ($c=0.50$) | Among people who do *not* switch, fraction who are Yes at both measurements. | Changes how concordant pairs split into Yes/Yes versus No/No; holding $q,r$ fixed, the theoretical McNemar power does not change. |

The simulated cell probabilities are $P(\text{No,No})=(1-q)(1-c)$, $P(\text{No,Yes})=qr$, $P(\text{Yes,No})=q(1-r)$, and $P(\text{Yes,Yes})=(1-q)c$.

The **true marginal change in the probability of Yes** from A to B is

$$
P(B=\text{Yes})-P(A=\text{Yes})=q(2r-1).
$$

For the initial settings $q=0.30$ and $r=0.70$, the true marginal increase is **0.12, or 12 percentage points**. A larger value of $c$ changes the overall Yes prevalence but **not this marginal change** when $q$ and $r$ stay fixed.

### 6.3 Reading the results

The **paired 2×2 table** counts all four transitions. The **discordant-pair bar graph** isolates the two directions that determine McNemar's statistic. The next graph shows an approximate chi-square(1) null distribution for the uncorrected and corrected versions. The final graph compares simulated rejection rates for **uncorrected**, **continuity-corrected**, and **exact binomial** McNemar procedures.

With only a few discordant pairs, the chi-square approximation can be poor. The **exact McNemar version** conditions on the observed number of discordances and uses a two-sided binomial calculation with probability 0.5 under the null. When there are no discordant pairs, the exact p-value shown is 1 and the asymptotic statistics are not estimable.

### Try it yourself — Experiments 8–9

**Experiment 8: Many changes, but no systematic direction.** Set $q=0.70$ and $r=0.50$. Compare a few new samples. *Question:* If 70% of participants change their answer, why might there still be no evidence of an overall change in the proportion of Yes responses?

**Experiment 9: Which pairs matter?** Set $q=0.15$, $r=0.80$, $c=0.20$, and keep $n$ fixed. Then change only $c$ to 0.80. *Predict:* What happens to the population proportions of No/No and Yes/Yes pairs? Should the **theoretical** power curve change? Why can a particular observed sample still change when the slider moves? Next increase $q$ and inspect the power curve.

## 7. Tab 5 — F-test: equal variances

**Purpose:** Compare the **variances**, not the means, of two independent *normal* populations. The true means are equal by construction, so an observed variance difference does not imply a mean difference.

### 7.1 Controls and test quantity

| Control (initial value) | Interpretation |
| --- | --- |
| **Observations per group** ($n=30$) | $n$ independent observations in **each** group. |
| **Population SD, group A (F-test only)** ($\sigma_A=1.5$) | Sets the overall measurement scale for both groups. |
| **True variance ratio** ($R=2$) | $R=\operatorname{Var}(B)/\operatorname{Var}(A)=\sigma_B^2/\sigma_A^2$. |
| **Draw new normal samples** | Repeats the independent sampling experiment. |

The app sets $\sigma_B=\sigma_A\sqrt{R}$. For example, $R=2$ means group B has **twice the variance**, but only about **1.41 times the standard deviation** of A. The observed statistic is

$$
F=\frac{s_B^2}{s_A^2}, \qquad H_0:\frac{\sigma_B^2}{\sigma_A^2}=1.
$$

### 7.2 Reading the graphs and cards

- **Normal populations:** two density curves with equal means but possibly different spreads.
- **Two-sided F-test:** the F reference distribution under equal variances; the two extreme tails are rejection regions. The observed statistic and critical values are marked.
- **Exact statistical power under normality:** rejection probability across sample sizes **per group**. At $R=1$, this is the test's null rejection probability; away from 1 it is power.
- **Summary cards:** observed F, two-sided p-value, true variance ratio, theoretical F power, and observed sample SD ratio. The comparison panel also gives a confidence interval for the **variance ratio** (not for a mean difference).

**Scale invariance:** If you change only the population SD of A, the app scales both groups by the same factor. Therefore the **variance ratio, observed F statistic, p-value, and theoretical power remain unchanged** for the retained simulated draws. The curves of individual observations nevertheless become narrower or wider in absolute measurement units.

**Assumption warning:** The classical variance-ratio F-test is particularly sensitive to departures from normality. Robust alternatives, such as the median-centered Levene/Brown–Forsythe procedure, may be preferable for non-normal data. Also, **do not use a preliminary F-test to select automatically between Student's pooled t-test and Welch's t-test**: such two-stage test selection can harm inferential properties.

### Try it yourself — Experiment 10

Set $R=1$ and $n=30$, draw several samples, and note that the observed ratio rarely equals exactly 1. Next set $R=2$, first with $n=10$ and then with $n=200$. *Question:* What happens to the exact power curve? Finally vary the common SD slider without changing $R$. *Question:* What remains invariant, and why?

## 8. Cross-tab interpretation: the design determines the test

| Research question | Data and dependency | Relevant tab / example test | What is **not** being tested |
| --- | --- | --- | --- |
| Do two independent groups have the same population mean? | Continuous; independent | Tab 1: Welch t-test | Equality of entire distributions |
| How reliable are mean-difference CIs across repeated studies? | Continuous; repeated independent studies | Tab 2: Welch CI coverage | Probability that an already observed fixed parameter changes |
| Are success probabilities different between independent groups? | Binary; independent | Tab 3: Pearson chi-square | Within-person before/after change |
| Is one direction of a binary within-person change more common? | Binary; paired | Tab 4: McNemar | Independence of two separate groups |
| Are two population variances equal? | Continuous; independent normal | Tab 5: F-test | Equality of means |

Notice that the **same numeric p-value** may have very different interpretations depending on the null hypothesis and design. Before reporting a p-value, state (1) the parameter or distribution feature of interest, (2) the study design, (3) the chosen test and its assumptions, and (4) the estimate and an appropriate measure of uncertainty where available.

## 9. Important cautions about the simulations

1. **These are simulated data, not evidence about a real intervention.** Even if a simulated difference is called an “effect,” the app does not establish causal effects in observational research.
2. **Normality is built into the continuous and F-test data generators.** The app does not demonstrate every possible non-normal shape or real-data problem.
3. **Welch and Student power curves are Monte Carlo estimates**, based on 5,000 simulated experiments at each design point. A separate equal-means Type I error panel uses 10,000 repetitions. The Wilcoxon rejection curve uses a large-sample approximation; the KS curve uses 350 repetitions per displayed grid point. The independent chi-square and McNemar power curves use 2,000 repetitions per grid point. F-test power is calculated analytically under normality.
4. **Some lines are intentionally approximate or slightly jagged.** These differences are numerical/simulation uncertainty, not statistical phenomena requiring an explanation from first principles. The categorical and paired power plots also interpolate between simulated grid points to mark the selected $n$.
5. **Statistical significance does not measure effect size or practical importance.** Report the estimated difference and relevant uncertainty, not only whether $p<0.05$.
6. **Failing to reject a null does not prove equivalence.** Demonstrating equivalence requires an explicitly specified equivalence margin and an appropriate analysis.
7. **Do not search across tests for the smallest p-value.** Testing many hypotheses or choosing procedures after seeing the data complicates the false-positive interpretation.
8. **Nominal does not always mean actual.** Under violated assumptions, a nominal 5% test may reject the true null more or less often than 5%, and a nominal 95% CI may have nonnominal coverage.

## 10. Review questions

Try to answer these without looking at the source code:

1. Why can two studies sampling the same populations report different p-values?
2. Why does increasing $n$ narrow the **sampling distribution** without narrowing the **population distribution**?
3. Can a study reject $H_0$ while its 95% CI still contains the true nonzero effect? Explain.
4. Under which conditions is a rejection probability properly called **power**, and when is it a **Type I error rate**?
5. Why can Student and Welch behave differently if the group variances and sample sizes are both unequal?
6. If two distributions have the same mean but different standard deviations, which of the selected tests can be sensitive to the difference in spread?
7. Why are the **off-diagonal cells** decisive for McNemar's test?
8. Does a twofold **variance ratio** imply a twofold **standard deviation ratio**?
9. What does an observed 95% CI tell you, and what does it *not* tell you?
10. In what situations would you be wary of a classical F-test or a large-sample chi-square approximation?

### Quick self-check

The central lessons are: **individual observations vary**, so **estimates vary**; more data typically reduce estimation uncertainty; a **p-value is conditional on a null model**, while **power and coverage describe repeated sampling**; the **null hypothesis differs between tests**; and **assumptions and dependence structures cannot be ignored**.

---

*Companion to the supplied `app.R` (version 5). This is an educational guide, not a substitute for a prespecified statistical analysis plan or expert review of real research data.*
