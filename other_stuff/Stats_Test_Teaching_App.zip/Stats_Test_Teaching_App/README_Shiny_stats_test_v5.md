# Understanding statistical tests, effect sizes and power — Shiny app v5

**Version 5** extends the original interactive teaching app with **independent sample sizes and standard deviations for the two continuous-outcome groups**, **Welch's two-sample t-test as the default**, and an **optional pooled-variance Student t-test**. It also updates the repeated-sampling/CI-coverage experiment and introduces a **separate simulation of the actual Type I error under the mean-equality null hypothesis**.

The application remains **English-language**, operates **locally/offline** after package installation, and needs **R and only the `shiny` add-on package**. Base `stats` supplies all tests and statistical functions.

## Files and start-up

Unzip the archive, open the `app.R` file in RStudio and click **Run App**. Or run:

```r
install.packages("shiny")  # Only once, requires internet for installation
shiny::runApp("path/to/the/unzipped/folder")
```

If the working directory contains `app.R`, `shiny::runApp("app.R")` also works. Statistical simulations run on your own computer. **No internet or data uploads** are used by the app.

## What's new in v5

| Control / result | Purpose |
|---|---|
| `Sample size, group A (n_A)` / `Sample size, group B (n_B)` | Investigate balanced and unbalanced designs; each group has its own control (5–300). |
| `Population SD, group A (sigma_A)` / `Population SD, group B (sigma_B)` | Investigate equal and unequal population variances (0.25–4.00). |
| `True mean difference (mu_B - mu_A)` | Set the actual population mean difference, with `mu_A = 0`. |
| **Welch t-test, always displayed** | Defaults to `t.test(B, A)` or `t.test(B, A, var.equal = FALSE)` in R. Does not require equal population variances. |
| **Optional checkbox: Student's pooled t-test** | Adds its test statistic, degrees of freedom, p-value, CI, rejection curve and repeated-sampling results **using the same samples**. In R: `t.test(B, A, var.equal = TRUE)`. |
| Separate **Type I error experiment** | Regardless of the currently selected true mean difference, simulates **40,000 studies with mu_A = mu_B** under the selected n's and SDs. This distinguishes proper Type I error control from apparent increases in power. |
| **Repeated samples & CI coverage** | Shows Welch confidence intervals by default, and if Student is enabled, overlays Student CIs for **the same independent studies**. Displays separate empirical CI coverage and rejection frequencies and their cumulative trends. |
| Updated nonparametric curves | Wilcoxon approximation handles **different n and SD**; KS is simulated for the selected design and additional points along the power curve. Their hypotheses concern **distributional equality**, not exclusively equality of means. |

### Continuous-data assumptions and definitions

Each group is independently sampled from a normal population:

- `A ~ Normal(0, sigma_A^2)` with `n_A` subjects.
- `B ~ Normal(delta, sigma_B^2)` with `n_B` subjects.

The exact **sampling standard deviation of the estimated mean difference**, given the simulated normal population parameters, is:

```
SE_true = sqrt(sigma_A^2 / n_A + sigma_B^2 / n_B)
```

This does **not** require equal population variances. The first chart plots the two population densities and their overlap (computed by integrating the minimum of the densities). The second chart shows the normal sampling distributions of the estimated mean difference under the null and under the specified alternative.

**Welch t-test:** It estimates the SE using `sqrt(s_A^2/n_A + s_B^2/n_B)` and estimates the degrees of freedom by the Welch–Satterthwaite formula. Its reference t distribution is an **approximation**, not an exact finite-sample result in general.

**Student's pooled t-test:** It pools the two estimated variances, using the weights `n_A - 1` and `n_B - 1`, and uses `n_A + n_B - 2` degrees of freedom. Under independent normal observations with equal population variances, the usual t-test has an exact reference distribution. If the true variances differ, the nominal alpha level can be strongly violated, particularly when group sample sizes are unequal.

For unequal SDs, there is **no unique canonical Cohen's d**. The card labelled *Standardized true difference* therefore explicitly uses `delta / sqrt((sigma_A^2 + sigma_B^2)/2)`, the equal-weight root-mean-square population SD, rather than presenting it as an unqualified Cohen's d.

### How the parametric power curves are calculated

The rejection probabilities for the Welch and pooled Student t-tests are **Monte Carlo estimates with 20,000 simulations per plotted design**, not falsely described as exact. This is essential because Student's classical noncentral-t power formula is not valid when the two population variances differ. The Welch test's p-values use sample-specific random degrees of freedom.

To simulate normally distributed observations efficiently, the app draws normal mean differences and chi-square sample variances. These are the **exact sufficient-statistic sampling laws for two independent normal samples**; consequently, the simulated test statistics have the same distributions as tests on complete simulated normal samples:

```
D_hat ~ Normal(delta, sigma_A^2/n_A + sigma_B^2/n_B)
(n_A-1)*s_A^2/sigma_A^2 ~ Chi-square(n_A-1)
(n_B-1)*s_B^2/sigma_B^2 ~ Chi-square(n_B-1)
```

The power chart has **total sample size N = n_A + n_B on the x-axis**. At other points the group-allocation ratio is kept approximately equal to the selected `n_A:n_B` ratio, with at least five observations per group. The exact selected group sizes are always included as a separate grid point. This matters because the notion of a power curve is otherwise ambiguous if both group sample sizes can vary independently.

The curve's vertical axis is the **rejection probability `P(p < alpha)`**. If the true mean difference is nonzero, this is power for the mean-equality t-tests. If `delta = 0`, it is the actual **Type I error probability**. For Student under unequal SDs, a larger rejection probability can be *incorrect Type I error inflation*, not an advantage.

Because the parametric curves are estimated, very small fluctuations (approximately a few tenths of a percentage point) are normal. The app fixes the random seed for each design to make slider-to-slider comparisons reproducible. As with any Monte Carlo estimate, those values are not exact.

### Independent Type I error experiment

At the bottom of the first tab, **40,000 entirely separate normal-model experiments under `delta = 0`** estimate the false-positive rejection rates using the selected group sizes, population SDs and alpha. This is displayed even if the delta slider above has been set to a nonzero true difference. It is therefore possible to compare *power under an alternative* with *the Type I error rate under the actual null* **without changing any other setting**.

A useful stress-test setting is:

| Setting | Group A | Group B |
|---|---:|---:|
| Sample size | 20 | 100 |
| Population SD | 3 | 1 |
| Population mean | 0 | 0 |

With a two-sided alpha of 0.05, the Welch null rejection rate should be near **5%**, while the pooled Student t-test may reject in roughly **28%** of such studies. This striking example illustrates an incorrect nominal level, not greater test quality. Reverse the imbalance (n_A = 100, n_B = 20) and observe that Student becomes highly conservative instead. Actual displayed rates will vary slightly from these indicative values because they are simulated.

### Confidence-interval coverage

The second tab draws 10, 20, 50, 100, 200, 500, or 1,000 independent studies from the selected populations. Each method calculates its **own SE, degrees of freedom, two-sided p-value and `(1-alpha)` confidence interval** for the difference of population means.

- **Blue vs orange interval:** covers vs fails to cover the **true mean difference**.
- **Filled rose dot:** rejects the **zero mean-difference null**, i.e. excludes zero; an open dot indicates non-rejection.
- **Dashed violet vertical line:** true mean difference; **dotted gray vertical line:** null difference (0).
- **Welch CI:** solid, positioned slightly above a row's center if Student is enabled.
- **Student CI:** dashed, positioned slightly below the *same row* if Student is enabled.

Under the correct normal equal-variance model, pooled Student t intervals have **exact nominal coverage**; Welch intervals normally have approximate nominal coverage. Under unequal true variances, especially with unequal n, pooled Student intervals may deviate strongly from nominal coverage. Both methods use their own consistent CI/test pair, so a test is significant at alpha precisely when its corresponding `(1-alpha)` two-sided CI excludes zero (subject only to floating-point rounding at a boundary).

The chart shows at most 100 studies by default for readability; the metrics and running rates always incorporate all simulated studies. A checkbox can show all intervals.

### Optional Wilcoxon and KS tests under unequal SDs

These options are preserved from versions 3–4. The **Wilcoxon rank-sum / Mann–Whitney** reference curve uses a large-sample normal approximation to the U-statistic including its moments under unequal sample sizes and unequal normal-population SDs. Small-sample accuracy may be limited; observed tests use base R `wilcox.test(..., exact = FALSE, correct = FALSE)`. The **two-sample Kolmogorov–Smirnov (KS)** rejection curve is simulated using 350 Monte Carlo replicates per plotted point; an observed test uses `ks.test(..., exact = FALSE)`. Both optional tests evaluate the *same observed data* as the t-tests.

**Very important:** Wilcoxon and KS generally test **equality of distributions** (or features of stochastic ordering), not just mean equality. With `sigma_A != sigma_B` and `delta = 0`, the normal populations already have **different distributions**. Then even a large rejection probability for Wilcoxon or KS is **not a Type I error for the hypothesis that the two distributions are equal**. Consequently, do not compare their curves as if all tests targeted exactly the same null hypothesis in that situation.

## Other tabs retained unchanged

| Tab | Population / design | What it shows |
|---|---|---|
| **Independent 2x2: chi-square** | Two independent groups, equal n, binary outcome | Pearson chi-square with and without Yates continuity correction; test statistic, p-value, two Monte Carlo rejection curves; signed phi and unsigned Cramer's V (= absolute phi in 2x2). |
| **McNemar: paired outcomes** | n paired subjects, binary before/after outcome | McNemar uncorrected/corrected; exact binomial alternative; discordant pairs; Monte Carlo rejection curves. |
| **F-test: equal variances** | Two independent normal groups with equal n; separate variance ratio | F test, test statistic, p-value, CI for variance ratio, exact F power. The F panel has its **own** n and sigma settings; it has not been merged with the two-sample mean experiment. |

The original common n slider now appears **only in these other three tabs**. The independent sample-size sliders `n_A` and `n_B` belong to the first two continuous-outcome tabs. The global alpha slider affects all tabs.

## Suggested teaching demonstrations

1. **Equal SDs, balanced n.** Set `n_A=n_B=30`, `sigma_A=sigma_B=1.5`, `delta=1`. Add Student. Their p-values, CIs, and power curves are very similar; neither test is much more powerful.
2. **Unequal SDs, balanced n.** Keep n_A = n_B = 30; set sigma_A = 3 and sigma_B = 1; delta = 0. Compare Student and Welch coverage and Type I error. Balanced groups mitigate some of the pooled Student problem.
3. **Unequal SDs, unbalanced n.** Set n_A = 20, n_B = 100; SD_A = 3, SD_B = 1; delta = 0. Look at the **separate Type I error experiment**, then set delta = 1 without changing the n's or SDs. The high Student rejection rate is now partly attributable to its defective false-positive control.
4. **Reverse which group is smaller.** Set n_A = 100, n_B = 20 with the same SDs. Student can now become too conservative. Thus variance inequality alone is not enough to determine the direction of the distortion.
5. **Repeat 1,000 CI experiments.** Turn on Student; compare the paired forest-plot intervals and both empirical coverage rates. Check that a narrow CI is *not* automatically a better CI if it has low long-run coverage.
6. **Interpret distributional alternatives carefully.** Set delta = 0 and unequal SDs; turn on Wilcoxon and KS. Ask students whether their null hypotheses are actually true under the chosen data-generating process.

## Dependencies and validation limitations

No additional R packages beyond **shiny** were added. The source was checked programmatically for R-style balanced delimiters, matching Shiny UI/output identifiers, distinct inputs, and references to defined inputs. The Welch/Student and Wilcoxon mathematical calculations were independently checked with SciPy simulations, including type-I error and coverage under balanced and unbalanced heteroscedastic designs. A full interactive R/Shiny runtime test **could not be performed here because R is not installed in this environment**. Please run it in RStudio before the teaching session and report any console errors if they appear.

Relevant R documentation: <https://stat.ethz.ch/R-manual/R-devel/library/stats/html/t.test.html>
